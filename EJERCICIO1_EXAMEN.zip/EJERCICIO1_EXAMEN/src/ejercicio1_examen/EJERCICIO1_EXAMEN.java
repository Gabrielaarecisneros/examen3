crear una  base de  datod llamada "agenda"  en  tu servidor Mysql local con una tabla llamada contactos, formada por tres campos:id nombre y telefono .
crea un programa  en java que funcione como una agenda  telefono sencillo con acceso a la base de datos indicanda . debera permitir el uso realizar 4 acciones distintas :mostrar todos los contactos el usuario intentara mediante teclado  y pantalla .todos los cambios  deberan  registrarse correctamente en la base de datos 
 entrega tambien la base de datos exportada en un acxhivo sql 


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EJERCICIO_EXAMEN;

import java.sql.CONTACTOS;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.mysql.cj.xdevapi.Statement;

import java.util.Scanner;

import java.util.Scanner;



/**
 *
 * @author DAW
 */
public class EJERCICIO1_EXAMEN {

    private static Object DriverManager;

    public static void main(String[] args) {
        try {
            //conectar con la base de datos
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://10.230.109.223?serverTimezone=UTC";
            Connection conn = DriverManager.getConnection(url, "root", "");
            Statement stmt = conn.createStatement();

        
            Scanner cs = new Scanner(System.in);
            int id, telefono;
            String nombre;
            boolean ex = true;


             //UTILIZAMOS LA AGENDA// 
            System.out.println("opcion 1 mostrar EL CONTACTO ");
            System.out.println("opcion 2 INSERTA EL  CONTACTO ");
            System.out.println("opcion 3 EDITA");
            System.out.println("opcion 4 BORRA-ELIMINA");
        
            int opcion = cs.nextInt();
            do {
                  //UTILIZO EL SWICH
                switch (opcion) {
                    //mostrar contactos
                    case 1:
                        ex = stmt.execute("USE AGENDA;");
                        ResultSet contacto = stmt.executeQuery("select * from contactos;");
                        while (contacto.next()) {
                            System.out.println(contacto.getInt("id") + contacto.getString("nombre") + contacto.getInt("telefono"));
                            break;
                        }
                        break;
                    //insertar contacto
                    case 2:
                        ex = stmt.execute("USE AGENDA;");
                        System.out.println("introduce id maximo 8 digitos");
                        id = cs.nextInt();
                        System.out.println("introduce nombre maximo 30 digitos");
                        nombre = cs.nextLine();
                        cs.next();
                        System.out.println("introduce telefono maximo 9 digitos");
                        telefono = cs.nextInt();
                        stmt.executeUpdate("insert into contactos (id,nombre,telefono)"
                                + "value(" + id + "," + NOMBRE  + "," + telefono + ")");
                        break;
                  
                    case 3:
                        ex = stmt.execute("USE AGENDA;");
                        System.out.println("introduce id a cambiar");
                        id = cs.nextInt();
                        System.out.println("introduce un nombre a cambiar");
                        nombre = cs.nextLine();
                        System.out.println("introduce un telefono a cambiar");
                        telefono = cs.nextInt();
                        stmt.execute("UPDATE contactos SET id = "+id+ ",nombre="+nombre + ",telefono="+telefono);
                        break;
                        /*EDITAMOS  LOS CONTACOTS */
                  
                    case 4:
                        ex = stmt.execute("USE AGENDA;");
                        System.out.println("introduce el nombre del registro que se requiere borrar");
                        String borrarNombre = cs.nextLine();
                        stmt.executeUpdate("DELETE FROM contactos WHERE nombre='" + borrarNombre + "');");
                        break;//BORRO LOS CONTACTOS//
                }
                stmt.close();
                conn.close();
            } while (opcion != 5);
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
