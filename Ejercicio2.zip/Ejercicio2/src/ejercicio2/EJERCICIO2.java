/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.*;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author DAW
 */
public class EJERCICIO2 {

 


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//tienes que mirar la ruta 
//C:\Users\DAW\Documents\NetBeansProjects\Ejercicio2\src
        String filePath = "C:\\Users\\DAW\\Documents\\NetBeansProjects\\aparcamientos.txt";
        File file = new File(filePath);
        //BUFFER 

        int numMixtos = 0;
        int numResidentes = 0;
        int numDisuasorios = 0;

        try ( FileReader fileReader = new FileReader(file);  BufferedReader bufferedReader = new BufferedReader(fileReader)) {

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] words = line.split(" ");
                for (String word : words) {
                    if (word.equals("MIXTOS")) {
                        numMixtos++;
                    } else if (word.equals("RESIDENTE")) {
                        numResidentes++;
                 
                    }
                }
                System.out.printf("MIXTOS: %d, RESIDENTES: %d, DISUASORIOS: %d\n", numMixtos, numResidentes, numDisuasorios);
                numMixtos = 0;
                numResidentes = 0;
                numDisuasorios = 0;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
